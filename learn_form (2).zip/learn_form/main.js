function calc_factorial(n)
{
    fact=1
    for(i=1;i<=n;i++)
    {
        fact*=i
    }
    return fact
}